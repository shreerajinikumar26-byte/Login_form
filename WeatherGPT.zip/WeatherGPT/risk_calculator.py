def calculate_risk(weather):

    rain = 0
    wind = 0

    if "rain" in weather:
        rain = weather["rain"].get("1h", 0)

    if "wind" in weather:
        wind = weather["wind"].get("speed", 0)

    if rain > 10 or wind > 15:
        return "HIGH", "Avoid unnecessary travel and follow official alerts."

    elif rain > 3 or wind > 8:
        return "MEDIUM", "Stay alert and monitor weather updates."

    else:
        return "LOW", "Weather conditions are currently relatively safe."