import requests
import os
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.getenv("WEATHER_API_KEY")


# -----------------------------------------
# SEARCH CITY / TOWN / DISTRICT / VILLAGE
# -----------------------------------------
def search_location(place):

    if not API_KEY:
        return None

    url = "https://api.openweathermap.org/geo/1.0/direct"

    params = {
        "q": f"{place},IN",
        "limit": 5,
        "appid": API_KEY
    }

    try:
        response = requests.get(url, params=params, timeout=10)

        print("Geocoding Status:", response.status_code)
        print("Geocoding Response:", response.text)

        if response.status_code == 200:

            locations = response.json()

            if locations:
                return locations[0]

        return None

    except Exception as e:
        print("Location Search Error:", e)
        return None


# -----------------------------------------
# GET WEATHER USING LATITUDE & LONGITUDE
# -----------------------------------------
def get_weather_by_coordinates(lat, lon):

    url = "https://api.openweathermap.org/data/2.5/weather"

    params = {
        "lat": lat,
        "lon": lon,
        "appid": API_KEY,
        "units": "metric"
    }

    try:
        response = requests.get(url, params=params, timeout=10)

        print("Weather Status:", response.status_code)

        return response.json()

    except Exception as e:
        return {
            "cod": "500",
            "message": str(e)
        }


# -----------------------------------------
# GET WEATHER FROM ANY PLACE NAME
# -----------------------------------------
def get_weather(place):

    # Step 1: Convert place name to coordinates
    location = search_location(place)

    if not location:
        return {
            "cod": "404",
            "message": (
                "Location not found. Try entering place name with "
                "district or state. Example: Omalur, Tamil Nadu"
            )
        }

    # Step 2: Get latitude and longitude
    lat = location["lat"]
    lon = location["lon"]

    # Step 3: Get weather using coordinates
    weather = get_weather_by_coordinates(lat, lon)

    # Add searched location details
    if str(weather.get("cod")) == "200":
        weather["searched_location"] = location.get("name", place)
        weather["lat"] = lat
        weather["lon"] = lon

    return weather