import streamlit as st

from weather_service import get_weather, get_weather_by_coordinates
from risk_calculator import calculate_risk
from chatbot_service import ask_weather_ai

st.set_page_config(
    page_title="WeatherGPT",
    page_icon="🌦️",
    layout="wide"
)

# -----------------------------
# TITLE
# -----------------------------

st.title("🌦️ WeatherGPT")
st.subheader("AI-Powered Weather & Disaster Management Assistant")

st.divider()

# -----------------------------
# SIDEBAR
# -----------------------------

st.sidebar.title("📍 Location")

location_mode = st.sidebar.radio(
    "Choose Location Method",
    ["Search Location", "Live Location"]
)

weather = None
location_name = None


# -----------------------------
# SEARCH LOCATION
# -----------------------------

if location_mode == "Search Location":

    city = st.sidebar.text_input(
        "Enter District / City / Village Name",
        placeholder="Example: Salem"
    )

    if st.sidebar.button("Get Weather"):

        if city:

            data = get_weather(city)

            if str(data.get("cod")) == "200":

                weather = data
                location_name = data["name"]

                st.session_state["weather"] = weather
                st.session_state["location"] = location_name

            else:
                st.error(
                    f"❌ Error: {data.get('message', 'Unknown error')}"
                )

        else:
            st.warning("⚠️ Please enter a location.")

# -----------------------------
# LIVE LOCATION
# -----------------------------

else:

    st.sidebar.info(
        "For prototype demo, enter GPS coordinates."
    )

    lat = st.sidebar.number_input(
        "Latitude",
        value=13.0827
    )

    lon = st.sidebar.number_input(
        "Longitude",
        value=80.2707
    )

    if st.sidebar.button("Use My Location"):

        data = get_weather_by_coordinates(lat, lon)

        if str(data.get("cod")) == "200":

            weather = data
            location_name = data["name"]

            st.session_state["weather"] = weather
            st.session_state["location"] = location_name


# -----------------------------
# SESSION DATA
# -----------------------------

if "weather" in st.session_state:

    weather = st.session_state["weather"]
    location_name = st.session_state["location"]

    st.success(f"📍 Current Location: {location_name}")

    # WEATHER VALUES

    temp = weather["main"]["temp"]
    humidity = weather["main"]["humidity"]
    description = weather["weather"][0]["description"]
    wind = weather["wind"]["speed"]

    # -----------------------------
    # METRICS
    # -----------------------------

    col1, col2, col3, col4 = st.columns(4)

    col1.metric("🌡️ Temperature", f"{temp} °C")
    col2.metric("💧 Humidity", f"{humidity}%")
    col3.metric("💨 Wind Speed", f"{wind} m/s")
    col4.metric("🌤️ Condition", description.title())

    st.divider()

    # -----------------------------
    # RISK ANALYSIS
    # -----------------------------

    st.subheader("🚨 Disaster Risk Analysis")

    risk, recommendation = calculate_risk(weather)

    if risk == "HIGH":
        st.error(f"🔴 Risk Level: {risk}")

    elif risk == "MEDIUM":
        st.warning(f"🟡 Risk Level: {risk}")

    else:
        st.success(f"🟢 Risk Level: {risk}")

    st.info(f"💡 Recommendation: {recommendation}")

    st.divider()

    # -----------------------------
    # CHATBOT
    # -----------------------------

    st.subheader("🤖 Ask WeatherGPT")

    question = st.text_input(
        "Ask about the weather",
        placeholder="Example: Inga inniku mazhai varuma?"
    )

    if st.button("Ask WeatherGPT 🤖"):

        if question:

            with st.spinner("WeatherGPT is thinking..."):

                answer = ask_weather_ai(
                    question,
                    weather,
                    location_name
                )

            st.chat_message("assistant").write(answer)

else:
    st.info("👈 Select a location and click Get Weather to start.")