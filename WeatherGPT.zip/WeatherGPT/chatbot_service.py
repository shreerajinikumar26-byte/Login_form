import os
from dotenv import load_dotenv
from google import genai

load_dotenv()

API_KEY = os.getenv("GEMINI_API_KEY")

client = genai.Client(api_key=API_KEY)


def get_fallback_answer(question, weather, location):

    question = question.lower()

    temperature = weather["main"]["temp"]
    humidity = weather["main"]["humidity"]
    description = weather["weather"][0]["description"]
    wind = weather["wind"]["speed"]

    # Rain related questions
    if any(word in question for word in [
        "rain", "mazhai", "மழை", "varuma"
    ]):

        return f"""
🌦️ **Weather Update for {location}**

Current condition: **{description.title()}**

🌡️ Temperature: **{temperature}°C**
💧 Humidity: **{humidity}%**

Based on the currently available weather data, please monitor the latest forecast and official alerts for rainfall updates.
"""

    # Travel questions
    elif any(word in question for word in [
        "travel", "safe", "poga", "போக"
    ]):

        if wind > 10:
            return f"""
⚠️ **Travel Advisory for {location}**

Current wind speed is **{wind} m/s**.

Please be cautious while travelling and monitor official weather alerts.
"""
        else:
            return f"""
✅ **Travel Advisory**

Current weather condition is **{description.title()}**.

Weather conditions appear relatively normal, but please check live alerts before travelling.
"""

    # General fallback
    else:
        return f"""
🤖 **WeatherGPT Update for {location}**

🌡️ Temperature: **{temperature}°C**
💧 Humidity: **{humidity}%**
💨 Wind Speed: **{wind} m/s**
🌤️ Condition: **{description.title()}**

Please ask me about rain, travel safety, weather conditions, or precautions.
"""


def ask_weather_ai(question, weather, location):

    try:

        temperature = weather["main"]["temp"]
        humidity = weather["main"]["humidity"]
        description = weather["weather"][0]["description"]
        wind = weather["wind"]["speed"]

        prompt = f"""
You are WeatherGPT, an AI Weather and Disaster Management Assistant.

User Location: {location}

Current Weather Data:
Temperature: {temperature} °C
Humidity: {humidity}%
Weather Condition: {description}
Wind Speed: {wind} m/s

User Question:
{question}

Rules:
- Give a short and useful answer.
- Answer in simple Tanglish if the user uses Tanglish.
- Do not invent weather data.
- Give safety recommendations when necessary.
"""

        response = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=prompt
        )

        return response.text

    except Exception as e:

        print("Gemini AI Error:", e)

        # Fallback system
        return get_fallback_answer(
            question,
            weather,
            location
        )