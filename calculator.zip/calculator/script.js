/**
 * Master Calculator - Complete Client-Side Application Script
 * 20 Precision Calculators with Responsive Dashboard, History & Theming
 */

'use strict';

/* ==========================================================================
   Global State & Data Definitions
   ========================================================================== */
const APP_STATE = {
  activeCalculatorId: null,
  theme: localStorage.getItem('mc_theme') || 'light',
  recentCalculators: JSON.parse(localStorage.getItem('mc_recent_calcs') || '[]'),
  history: JSON.parse(localStorage.getItem('mc_calc_history') || '[]'),
  currentCategory: 'all'
};

/* Calculator Catalog Metadata & Formula Information */
const CALCULATOR_CATALOG = {
  'basic': {
    name: 'Basic Calculator',
    icon: '🧮',
    category: 'Everyday & Math',
    formulaTitle: 'Basic Arithmetic Operations',
    formula: 'Standard decimal arithmetic: Addition (+), Subtraction (-), Multiplication (×), Division (÷), and Percentage (%). Follows standard operator precedence.'
  },
  'scientific': {
    name: 'Scientific Calculator',
    icon: '🔬',
    category: 'Everyday & Math',
    formulaTitle: 'Scientific Trigonometric & Transcendental Functions',
    formula: 'Trigonometry: sin(x), cos(x), tan(x) (supports DEG / RAD modes). Logarithms: log₁₀(x) and ln(x). Exponentials: x^y, √x, x². Factorial: n! = n × (n-1) × ... × 1. Constants: π ≈ 3.14159, e ≈ 2.71828.'
  },
  'percentage': {
    name: 'Percentage Calculator',
    icon: '📊',
    category: 'Everyday & Math',
    formulaTitle: 'Percentage Formulas',
    formula: '1. What is P% of Y? Formula: (P / 100) × Y\n2. % Change: ((Final - Initial) / |Initial|) × 100\n3. % Difference: (|V1 - V2| / ((V1 + V2) / 2)) × 100'
  },
  'age': {
    name: 'Age Calculator',
    icon: '🎂',
    category: 'Date & Time',
    formulaTitle: 'Gregorian Calendar Exact Difference',
    formula: 'Calculates the exact elapsed duration between date of birth and reference date, adjusting for differing month days (28, 29, 30, 31) and leap years.'
  },
  'bmi': {
    name: 'BMI Health Calculator',
    icon: '⚖️',
    category: 'Health & Fitness',
    formulaTitle: 'World Health Organization (WHO) BMI Formula',
    formula: 'Metric: BMI = weight (kg) / [height (m)]²\nUS Units: BMI = [weight (lbs) × 703] / [height (in)]²\nCategories: Underweight (<18.5), Normal (18.5-24.9), Overweight (25-29.9), Obese (≥30.0).'
  },
  'loan': {
    name: 'Loan / EMI Calculator',
    icon: '💳',
    category: 'Finance & Commerce',
    formulaTitle: 'Equated Monthly Installment (EMI) Formula',
    formula: 'EMI = [P × r × (1 + r)ⁿ] / [(1 + r)ⁿ - 1]\nWhere P = Principal Loan Amount, r = Monthly Interest Rate (Annual Rate / 12 / 100), n = Total Tenure in Months.'
  },
  'simple-interest': {
    name: 'Simple Interest Calculator',
    icon: '📈',
    category: 'Finance & Commerce',
    formulaTitle: 'Simple Interest Formula',
    formula: 'SI = (P × R × T) / 100\nTotal Maturity Value A = P + SI\nWhere P = Principal, R = Annual Rate %, T = Time period in years.'
  },
  'compound-interest': {
    name: 'Compound Interest Calculator',
    icon: '💹',
    category: 'Finance & Commerce',
    formulaTitle: 'Compound Interest with Compounding Frequency',
    formula: 'Future Value A = P × (1 + r/n)ⁿᵗ + PMT × [((1 + r/n)ⁿᵗ - 1) / (r/n)]\nWhere P = Initial Deposit, r = Annual Rate / 100, n = Compounding frequency per year, t = Years, PMT = Monthly Deposit.'
  },
  'gst': {
    name: 'GST Calculator',
    icon: '🏷️',
    category: 'Finance & Commerce',
    formulaTitle: 'Goods & Services Tax (GST) Formula',
    formula: 'Add GST: GST = Price × (Rate / 100), Gross = Price + GST\nRemove GST: Net = Gross / (1 + Rate / 100), GST = Gross - Net\nIn India & dual regimes: CGST = GST / 2, SGST = GST / 2.'
  },
  'discount': {
    name: 'Discount Calculator',
    icon: '🎟️',
    category: 'Finance & Commerce',
    formulaTitle: 'Retail Discount & Tax Formula',
    formula: 'Discount Amount = Original Price × (Discount % / 100)\nPrice After Discount = Original Price - Discount Amount\nFinal Price = Price After Discount × (1 + Tax % / 100)'
  },
  'profit-loss': {
    name: 'Profit & Loss Calculator',
    icon: '💼',
    category: 'Academic & Stats',
    formulaTitle: 'Commercial Profit & Loss Equations',
    formula: 'Net = Selling Price (SP) - Cost Price (CP)\nProfit % = (Profit / CP) × 100\nLoss % = (Loss / CP) × 100\nMarkup % = ((SP - CP) / CP) × 100\nMargin % = ((SP - CP) / SP) × 100'
  },
  'time': {
    name: 'Time Calculator',
    icon: '⏱️',
    category: 'Date & Time',
    formulaTitle: 'Time Span & Arithmetic',
    formula: 'Converts hours and minutes to elapsed timestamps. Handles 24-hour midnight wrap-around when End Time is numerically smaller than Start Time.'
  },
  'date-diff': {
    name: 'Date Difference Calculator',
    icon: '📅',
    category: 'Date & Time',
    formulaTitle: 'Day Span & Business Days',
    formula: 'Total Days = End Date - Start Date (in milliseconds / 86,400,000).\nBusiness Days loop excludes Saturdays (day 6) and Sundays (day 0).'
  },
  'unit-converter': {
    name: 'Unit Converter',
    icon: '📐',
    category: 'Converters',
    formulaTitle: 'Unit Conversion Multipliers',
    formula: 'Converts input value to base SI unit (meters, kilograms, Kelvin, etc.) and multiplies by target unit reciprocal factor.'
  },
  'currency': {
    name: 'Currency Converter',
    icon: '💱',
    category: 'Converters',
    formulaTitle: 'Foreign Exchange Rate Conversion',
    formula: 'Converted = (Amount / Rate[FromCurrency]) × Rate[ToCurrency], where rates are referenced against USD base baseline.'
  },
  'cgpa': {
    name: 'CGPA Calculator',
    icon: '🎓',
    category: 'Academic & Stats',
    formulaTitle: 'Cumulative Grade Point Average (CGPA)',
    formula: 'CGPA = ∑(Semester GPA × Semester Credits) / ∑(Semester Credits)\nPercentage conversion: CBSE/AICTE standard: Percentage = CGPA × 9.5; Proportional standard: (CGPA / Scale) × 100.'
  },
  'gpa': {
    name: 'GPA Calculator',
    icon: '📝',
    category: 'Academic & Stats',
    formulaTitle: 'Semester Grade Point Average',
    formula: 'GPA = ∑(Course Grade Points × Course Credits) / ∑(Total Credits)\nGrading scale: A+ (4.0), A (4.0), A- (3.7), B+ (3.3), B (3.0), B- (2.7), C+ (2.3), C (2.0), C- (1.7), D (1.0), F (0.0).'
  },
  'average': {
    name: 'Average Calculator',
    icon: '🔢',
    category: 'Everyday & Math',
    formulaTitle: 'Arithmetic Mean & Dataset Properties',
    formula: 'Arithmetic Mean = (∑x) / n\nMedian = Middle value of sorted data set\nRange = Maximum - Minimum'
  },
  'ratio': {
    name: 'Ratio Calculator',
    icon: '➗',
    category: 'Everyday & Math',
    formulaTitle: 'Proportions & Simplification',
    formula: 'Proportion: A/B = C/D => Cross multiplication A × D = B × C\nSimplification: Divide A and B by their Greatest Common Divisor: GCD(A, B).'
  },
  'statistics': {
    name: 'Statistics Calculator',
    icon: '📉',
    category: 'Academic & Stats',
    formulaTitle: 'Descriptive Statistics Formulas',
    formula: 'Sample Standard Deviation s = √[∑(x - x̄)² / (n - 1)]\nPopulation Standard Deviation σ = √[∑(x - μ)² / n]\nSample Variance = s²\nInterquartile Range IQR = Q₃ - Q₁'
  }
};

/* ==========================================================================
   Initialization & Event Listeners
   ========================================================================== */
document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  initRecentCalculators();
  initCategoryFilters();
  initSearch();
  initHeaderNavigation();
  initHistory();
  initDefaultCalculatorStates();
  initKeyboardShortcuts();
  checkUrlHash();

  window.addEventListener('hashchange', checkUrlHash);
});

/* ==========================================================================
   Theme Management (Light / Dark Mode)
   ========================================================================== */
function initTheme() {
  document.documentElement.setAttribute('data-theme', APP_STATE.theme);
  updateThemeIcon();

  const themeBtn = document.getElementById('themeToggleBtn');
  if (themeBtn) {
    themeBtn.addEventListener('click', toggleTheme);
  }
}

function toggleTheme() {
  APP_STATE.theme = APP_STATE.theme === 'light' ? 'dark' : 'light';
  document.documentElement.setAttribute('data-theme', APP_STATE.theme);
  localStorage.setItem('mc_theme', APP_STATE.theme);
  updateThemeIcon();
  showToast(`Switched to ${APP_STATE.theme} mode`);
}

function updateThemeIcon() {
  const themeBtn = document.getElementById('themeToggleBtn');
  if (!themeBtn) return;
  if (APP_STATE.theme === 'dark') {
    themeBtn.innerHTML = `
      <svg class="moon-icon" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"></path>
      </svg>
    `;
    themeBtn.setAttribute('title', 'Switch to Light mode');
  } else {
    themeBtn.innerHTML = `
      <svg class="sun-icon" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
        <circle cx="12" cy="12" r="5"></circle>
        <path stroke-linecap="round" stroke-linejoin="round" d="M12 1v2m0 18v2M4.22 4.22l1.42 1.42m12.72 12.72l1.42 1.42M1 12h2m18 0h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"></path>
      </svg>
    `;
    themeBtn.setAttribute('title', 'Switch to Dark mode');
  }
}

/* ==========================================================================
   Header & Mobile Navigation
   ========================================================================== */
function initHeaderNavigation() {
  const mobileMenuBtn = document.getElementById('mobileMenuBtn');
  const navMenu = document.getElementById('navMenu');

  if (mobileMenuBtn && navMenu) {
    mobileMenuBtn.addEventListener('click', () => {
      navMenu.classList.toggle('open');
    });

    navMenu.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => {
        navMenu.classList.remove('open');
      });
    });
  }

  // Quick Search Focus button in header
  const quickSearchBtn = document.getElementById('quickSearchBtn');
  const searchInput = document.getElementById('calculatorSearchInput');
  if (quickSearchBtn && searchInput) {
    quickSearchBtn.addEventListener('click', () => {
      searchInput.focus();
      searchInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
  }
}

/* ==========================================================================
   Search & Category Filtering
   ========================================================================== */
function initSearch() {
  const searchInput = document.getElementById('calculatorSearchInput');
  const clearBtn = document.getElementById('searchClearBtn');

  if (searchInput) {
    searchInput.addEventListener('input', () => {
      const query = searchInput.value.trim().toLowerCase();
      if (clearBtn) {
        clearBtn.classList.toggle('visible', query.length > 0);
      }
      filterCalculators();
    });
  }

  if (clearBtn) {
    clearBtn.addEventListener('click', clearCalculatorSearch);
  }
}

function clearCalculatorSearch() {
  const searchInput = document.getElementById('calculatorSearchInput');
  const clearBtn = document.getElementById('searchClearBtn');
  if (searchInput) {
    searchInput.value = '';
    searchInput.focus();
  }
  if (clearBtn) {
    clearBtn.classList.remove('visible');
  }
  filterCalculators();
}

function initCategoryFilters() {
  const filterChips = document.querySelectorAll('.category-filter-bar .filter-chip');
  filterChips.forEach(chip => {
    chip.addEventListener('click', () => {
      filterChips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      APP_STATE.currentCategory = chip.getAttribute('data-category');
      filterCalculators();
    });
  });
}

function filterCalculators() {
  const searchInput = document.getElementById('calculatorSearchInput');
  const query = searchInput ? searchInput.value.trim().toLowerCase() : '';
  const selectedCat = APP_STATE.currentCategory;
  const cards = document.querySelectorAll('.calculators-grid .calc-card');
  const noResultsBox = document.getElementById('noSearchResults');

  let visibleCount = 0;

  cards.forEach(card => {
    const cardCategory = card.getAttribute('data-category');
    const title = (card.querySelector('.calc-card-title')?.textContent || '').toLowerCase();
    const desc = (card.querySelector('.calc-card-desc')?.textContent || '').toLowerCase();
    const keywords = (card.getAttribute('data-keywords') || '').toLowerCase();

    const matchesCategory = (selectedCat === 'all' || cardCategory === selectedCat);
    const matchesSearch = query === '' || title.includes(query) || desc.includes(query) || keywords.includes(query);

    if (matchesCategory && matchesSearch) {
      card.style.display = 'flex';
      visibleCount++;
    } else {
      card.style.display = 'none';
    }
  });

  if (noResultsBox) {
    noResultsBox.style.display = visibleCount === 0 ? 'block' : 'none';
  }
}

/* ==========================================================================
   Recently Used Calculators
   ========================================================================== */
function initRecentCalculators() {
  renderRecentCalculators();
}

function markCalculatorAsRecent(id) {
  if (!CALCULATOR_CATALOG[id]) return;
  // Remove if already present
  APP_STATE.recentCalculators = APP_STATE.recentCalculators.filter(item => item !== id);
  // Prepend to top
  APP_STATE.recentCalculators.unshift(id);
  // Cap at 6 recent
  if (APP_STATE.recentCalculators.length > 6) {
    APP_STATE.recentCalculators.pop();
  }
  localStorage.setItem('mc_recent_calcs', JSON.stringify(APP_STATE.recentCalculators));
  renderRecentCalculators();
}

function renderRecentCalculators() {
  const container = document.getElementById('recentPillsContainer');
  const section = document.getElementById('recentlyUsedSection');
  if (!container || !section) return;

  if (APP_STATE.recentCalculators.length === 0) {
    section.classList.add('hidden');
    return;
  }

  section.classList.remove('hidden');
  container.innerHTML = APP_STATE.recentCalculators.map(id => {
    const calc = CALCULATOR_CATALOG[id];
    if (!calc) return '';
    return `
      <button type="button" class="recent-pill-btn" onclick="openCalculator('${id}')">
        <span>${calc.icon}</span>
        <span>${calc.name}</span>
      </button>
    `;
  }).join('');
}

/* ==========================================================================
   Dedicated Calculator Workspace Modal & Deep Linking
   ========================================================================== */
function openCalculator(id) {
  if (!CALCULATOR_CATALOG[id]) return;

  APP_STATE.activeCalculatorId = id;
  markCalculatorAsRecent(id);

  const backdrop = document.getElementById('calcModalBackdrop');
  const workspaceTitle = document.getElementById('workspaceTitle');
  const workspaceIcon = document.getElementById('workspaceIcon');
  const workspaceCategory = document.getElementById('workspaceCategory');
  const formulaBox = document.getElementById('workspaceFormulaBox');
  const formulaBoxContent = document.getElementById('formulaBoxContent');

  const meta = CALCULATOR_CATALOG[id];
  if (workspaceTitle) workspaceTitle.textContent = meta.name;
  if (workspaceIcon) workspaceIcon.textContent = meta.icon;
  if (workspaceCategory) workspaceCategory.textContent = meta.category;

  // Set formula content
  if (formulaBoxContent) {
    formulaBoxContent.innerHTML = `
      <p style="margin-bottom: 0.5rem; font-weight: 600;">${meta.formulaTitle}</p>
      <pre class="info-formula-code">${escapeHtml(meta.formula)}</pre>
    `;
  }
  if (formulaBox) formulaBox.style.display = 'none';

  // Hide all panes, show target pane
  document.querySelectorAll('.calc-pane').forEach(pane => {
    pane.style.display = 'none';
  });

  const targetPane = document.getElementById(`pane-${id}`);
  if (targetPane) {
    targetPane.style.display = 'block';
  }

  // Open backdrop
  if (backdrop) {
    backdrop.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  // Update URL hash cleanly
  if (window.location.hash !== `#${id}`) {
    history.pushState(null, null, `#${id}`);
  }

  // Trigger default computation for active tool
  triggerInitialCalc(id);
}

function closeCalculator() {
  const backdrop = document.getElementById('calcModalBackdrop');
  if (backdrop) {
    backdrop.classList.remove('active');
    document.body.style.overflow = '';
  }
  APP_STATE.activeCalculatorId = null;

  // Remove hash without scrolling
  if (window.location.hash) {
    history.pushState(null, null, window.location.pathname + window.location.search);
  }
}

function checkUrlHash() {
  const hash = window.location.hash.replace('#', '').trim();
  if (hash && CALCULATOR_CATALOG[hash]) {
    openCalculator(hash);
  } else if (!hash && APP_STATE.activeCalculatorId) {
    closeCalculator();
  }
}

// Modal Header Formula Toggle & Close Listeners
document.addEventListener('DOMContentLoaded', () => {
  const closeBtn = document.getElementById('workspaceCloseBtn');
  if (closeBtn) closeBtn.addEventListener('click', closeCalculator);

  const backdrop = document.getElementById('calcModalBackdrop');
  if (backdrop) {
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) closeCalculator();
    });
  }

  const formulaBtn = document.getElementById('workspaceFormulaBtn');
  const formulaBox = document.getElementById('workspaceFormulaBox');
  if (formulaBtn && formulaBox) {
    formulaBtn.addEventListener('click', () => {
      formulaBox.style.display = formulaBox.style.display === 'none' ? 'block' : 'none';
    });
  }
});

function triggerInitialCalc(id) {
  switch (id) {
    case 'percentage': calcPercentage(); break;
    case 'age': calcAge(); break;
    case 'bmi': calcBMI(); break;
    case 'loan': calcLoan(); break;
    case 'simple-interest': calcSimpleInterest(); break;
    case 'compound-interest': calcCompoundInterest(); break;
    case 'gst': calcGST(); break;
    case 'discount': calcDiscount(); break;
    case 'profit-loss': calcProfitLoss(); break;
    case 'time': calcTime(); break;
    case 'date-diff': calcDateDiff(); break;
    case 'unit-converter': convertUnits(); break;
    case 'currency': convertCurrency(); break;
    case 'cgpa': calcCGPA(); break;
    case 'gpa': calcGPA(); break;
    case 'average': calcAverage(); break;
    case 'ratio': calcRatio(); break;
    case 'statistics': calcStatistics(); break;
  }
}

/* ==========================================================================
   Calculation History System
   ========================================================================== */
function initHistory() {
  updateHistoryBadge();
  renderHistoryList();

  const historyTrigger = document.getElementById('historyTriggerBtn');
  const historyClose = document.getElementById('historyCloseBtn');
  const historyBackdrop = document.getElementById('historyDrawerBackdrop');

  if (historyTrigger && historyBackdrop) {
    historyTrigger.addEventListener('click', () => {
      historyBackdrop.classList.add('active');
      document.body.style.overflow = 'hidden';
    });
  }

  if (historyClose && historyBackdrop) {
    historyClose.addEventListener('click', () => {
      historyBackdrop.classList.remove('active');
      document.body.style.overflow = '';
    });
  }

  if (historyBackdrop) {
    historyBackdrop.addEventListener('click', (e) => {
      if (e.target === historyBackdrop) {
        historyBackdrop.classList.remove('active');
        document.body.style.overflow = '';
      }
    });
  }
}

function recordCalculation(calcId, expression, result) {
  if (!result || result === '-' || result === 'Error') return;

  const meta = CALCULATOR_CATALOG[calcId] || { name: 'Calculator', icon: '🧮' };
  const entry = {
    calcId,
    name: meta.name,
    icon: meta.icon,
    expression: expression || meta.name,
    result: String(result),
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  };

  APP_STATE.history.unshift(entry);
  if (APP_STATE.history.length > 50) {
    APP_STATE.history.pop();
  }

  localStorage.setItem('mc_calc_history', JSON.stringify(APP_STATE.history));
  updateHistoryBadge();
  renderHistoryList();
}

function updateHistoryBadge() {
  const badge = document.getElementById('historyBadgeCount');
  if (badge) {
    badge.textContent = APP_STATE.history.length;
    badge.style.display = APP_STATE.history.length > 0 ? 'flex' : 'none';
  }
}

function renderHistoryList() {
  const container = document.getElementById('historyListContainer');
  if (!container) return;

  if (APP_STATE.history.length === 0) {
    container.innerHTML = `
      <div class="history-empty">
        <p style="font-size: 2rem; margin-bottom: 0.5rem;">📜</p>
        <p style="font-weight: 600; color: var(--text-main);">No calculation history yet</p>
        <p style="font-size: 0.85rem; color: var(--text-muted); margin-top: 0.25rem;">Perform calculations to see them logged here.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = APP_STATE.history.map((item, index) => `
    <div class="history-item" onclick="copyCurrentResult('${escapeHtml(item.result)}')">
      <div class="history-item-top">
        <span class="history-item-calc">${item.icon} ${item.name}</span>
        <span>${item.timestamp}</span>
      </div>
      <div class="history-item-expr">${escapeHtml(item.expression)}</div>
      <div class="history-item-res">= ${escapeHtml(item.result)}</div>
    </div>
  `).join('');
}

function clearCalculationHistory() {
  APP_STATE.history = [];
  localStorage.removeItem('mc_calc_history');
  updateHistoryBadge();
  renderHistoryList();
  showToast('Calculation history cleared');
}

/* ==========================================================================
   Toast Notification & Clipboard Utilities
   ========================================================================== */
function showToast(message, type = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast ${type === 'success' ? 'toast-success' : type === 'error' ? 'toast-error' : ''}`;
  toast.innerHTML = `
    <span>${type === 'success' ? '✓' : type === 'error' ? '⚠️' : 'ℹ️'}</span>
    <span>${message}</span>
  `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px) scale(0.95)';
    setTimeout(() => {
      if (toast.parentNode) toast.parentNode.removeChild(toast);
    }, 200);
  }, 3000);
}

function copyCurrentResult(val) {
  if (!val || val === '-' || val === '--') {
    showToast('No result available to copy', 'error');
    return;
  }
  const cleanVal = String(val).replace(/^[=]/, '').trim();
  navigator.clipboard.writeText(cleanVal).then(() => {
    showToast(`Copied "${cleanVal}" to clipboard!`, 'success');
  }).catch(() => {
    showToast('Failed to copy to clipboard', 'error');
  });
}

function escapeHtml(str) {
  if (typeof str !== 'string') return str;
  return str.replace(/[&<>"']/g, m => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[m]));
}

/* FAQ Accordion Toggle */
function toggleFaq(btn) {
  const item = btn.closest('.faq-item');
  if (!item) return;
  item.classList.toggle('active');
}

/* Keyboard Shortcuts */
function initKeyboardShortcuts() {
  window.addEventListener('keydown', (e) => {
    // Quick search shortcut "/"
    if (e.key === '/' && document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA') {
      e.preventDefault();
      const searchInput = document.getElementById('calculatorSearchInput');
      if (searchInput) {
        searchInput.focus();
        searchInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }

    // Escape closes modal or history
    if (e.key === 'Escape') {
      const modal = document.getElementById('calcModalBackdrop');
      const historyDrawer = document.getElementById('historyDrawerBackdrop');
      if (historyDrawer && historyDrawer.classList.contains('active')) {
        historyDrawer.classList.remove('active');
        document.body.style.overflow = '';
      } else if (modal && modal.classList.contains('active')) {
        closeCalculator();
      }
    }

    // Basic calculator keypad keys
    if (APP_STATE.activeCalculatorId === 'basic') {
      handleBasicKeypadKeyboard(e);
    }
  });
}

/* ==========================================================================
   1. BASIC CALCULATOR
   ========================================================================== */
let basicState = {
  currentInput: '0',
  previousInput: null,
  operation: null,
  waitingForSecondOperand: false,
  historyExpression: ''
};

function updateBasicDisplay() {
  const currentEl = document.getElementById('basicCurrentDisplay');
  const historyEl = document.getElementById('basicExprHistory');
  if (currentEl) currentEl.innerText = basicState.currentInput;
  if (historyEl) historyEl.innerText = basicState.historyExpression || '\u00A0';
}

function basicInputDigit(digit) {
  if (basicState.waitingForSecondOperand) {
    basicState.currentInput = digit;
    basicState.waitingForSecondOperand = false;
  } else {
    basicState.currentInput = basicState.currentInput === '0' ? digit : basicState.currentInput + digit;
  }
  updateBasicDisplay();
}

function basicInputDot() {
  if (basicState.waitingForSecondOperand) {
    basicState.currentInput = '0.';
    basicState.waitingForSecondOperand = false;
    updateBasicDisplay();
    return;
  }
  if (!basicState.currentInput.includes('.')) {
    basicState.currentInput += '.';
    updateBasicDisplay();
  }
}

function basicOp(nextOp) {
  const inputValue = parseFloat(basicState.currentInput);

  if (basicState.operation && basicState.waitingForSecondOperand) {
    basicState.operation = nextOp;
    basicState.historyExpression = `${basicState.previousInput} ${getOpSymbol(nextOp)}`;
    updateBasicDisplay();
    return;
  }

  if (basicState.previousInput == null && !isNaN(inputValue)) {
    basicState.previousInput = inputValue;
  } else if (basicState.operation) {
    const result = performBasicCalculation(basicState.operation, basicState.previousInput, inputValue);
    basicState.currentInput = String(result);
    basicState.previousInput = result;
  }

  basicState.waitingForSecondOperand = true;
  basicState.operation = nextOp;
  basicState.historyExpression = `${basicState.previousInput} ${getOpSymbol(nextOp)}`;
  updateBasicDisplay();
}

function basicCalculate() {
  if (!basicState.operation || basicState.previousInput == null) return;
  const inputValue = parseFloat(basicState.currentInput);
  const expr = `${basicState.previousInput} ${getOpSymbol(basicState.operation)} ${inputValue}`;
  const result = performBasicCalculation(basicState.operation, basicState.previousInput, inputValue);

  basicState.historyExpression = `${expr} =`;
  basicState.currentInput = String(result);
  basicState.previousInput = null;
  basicState.operation = null;
  basicState.waitingForSecondOperand = false;

  updateBasicDisplay();
  recordCalculation('basic', expr, result);
}

function performBasicCalculation(op, first, second) {
  switch (op) {
    case '+': return roundSmart(first + second);
    case '-': return roundSmart(first - second);
    case '*': return roundSmart(first * second);
    case '/': return second === 0 ? 'Error' : roundSmart(first / second);
    default: return second;
  }
}

function getOpSymbol(op) {
  switch (op) {
    case '+': return '+';
    case '-': return '-';
    case '*': return '×';
    case '/': return '÷';
    default: return op;
  }
}

function basicClearAll() {
  basicState = {
    currentInput: '0',
    previousInput: null,
    operation: null,
    waitingForSecondOperand: false,
    historyExpression: ''
  };
  updateBasicDisplay();
}

function basicClearEntry() {
  basicState.currentInput = '0';
  updateBasicDisplay();
}

function basicBackspace() {
  if (basicState.currentInput.length > 1) {
    basicState.currentInput = basicState.currentInput.slice(0, -1);
  } else {
    basicState.currentInput = '0';
  }
  updateBasicDisplay();
}

function basicNegate() {
  const val = parseFloat(basicState.currentInput);
  if (!isNaN(val)) {
    basicState.currentInput = String(-val);
    updateBasicDisplay();
  }
}

function basicPercentage() {
  const val = parseFloat(basicState.currentInput);
  if (!isNaN(val)) {
    basicState.currentInput = String(roundSmart(val / 100));
    updateBasicDisplay();
  }
}

function handleBasicKeypadKeyboard(e) {
  if (e.key >= '0' && e.key <= '9') basicInputDigit(e.key);
  else if (e.key === '.') basicInputDot();
  else if (e.key === '+' || e.key === '-' || e.key === '*' || e.key === '/') basicOp(e.key);
  else if (e.key === 'Enter' || e.key === '=') { e.preventDefault(); basicCalculate(); }
  else if (e.key === 'Backspace') basicBackspace();
  else if (e.key === 'Escape') basicClearAll();
}

/* ==========================================================================
   2. SCIENTIFIC CALCULATOR
   ========================================================================== */
let sciState = {
  currentInput: '0',
  expressionHistory: '',
  isDegMode: true,
  freshResult: false
};

function updateSciDisplay() {
  const currEl = document.getElementById('sciCurrentDisplay');
  const exprEl = document.getElementById('sciExprHistory');
  const degIndicator = document.getElementById('sciAngleModeIndicator');
  const degBtn = document.getElementById('sciAngleToggleBtn');

  if (currEl) currEl.innerText = sciState.currentInput;
  if (exprEl) exprEl.innerText = sciState.expressionHistory || '\u00A0';
  if (degIndicator) degIndicator.innerText = sciState.isDegMode ? 'DEG' : 'RAD';
  if (degBtn) degBtn.innerText = sciState.isDegMode ? 'DEG' : 'RAD';
}

function sciToggleAngleMode() {
  sciState.isDegMode = !sciState.isDegMode;
  updateSciDisplay();
  showToast(`Angle mode: ${sciState.isDegMode ? 'Degrees' : 'Radians'}`);
}

function sciInputDigit(digit) {
  if (sciState.freshResult || sciState.currentInput === '0') {
    sciState.currentInput = digit;
    sciState.freshResult = false;
  } else {
    sciState.currentInput += digit;
  }
  updateSciDisplay();
}

function sciInputDot() {
  if (sciState.freshResult) {
    sciState.currentInput = '0.';
    sciState.freshResult = false;
    updateSciDisplay();
    return;
  }
  if (!sciState.currentInput.endsWith('.')) {
    sciState.currentInput += '.';
    updateSciDisplay();
  }
}

function sciOp(op) {
  sciState.freshResult = false;
  sciState.currentInput += ` ${op} `;
  updateSciDisplay();
}

function sciInsert(symbol) {
  if (sciState.freshResult) {
    sciState.currentInput = symbol;
    sciState.freshResult = false;
  } else if (sciState.currentInput === '0') {
    sciState.currentInput = symbol;
  } else {
    sciState.currentInput += symbol;
  }
  updateSciDisplay();
}

function sciConst(c) {
  const val = c === 'pi' ? Math.PI : Math.E;
  if (sciState.freshResult || sciState.currentInput === '0') {
    sciState.currentInput = String(roundSmart(val));
    sciState.freshResult = false;
  } else {
    sciState.currentInput += String(roundSmart(val));
  }
  updateSciDisplay();
}

function sciNegate() {
  try {
    const val = parseFloat(sciState.currentInput);
    if (!isNaN(val)) {
      sciState.currentInput = String(-val);
      updateSciDisplay();
    }
  } catch(e) {}
}

function sciClearAll() {
  sciState.currentInput = '0';
  sciState.expressionHistory = '';
  sciState.freshResult = false;
  updateSciDisplay();
}

function sciBackspace() {
  if (sciState.currentInput.length > 1) {
    sciState.currentInput = sciState.currentInput.trimEnd();
    sciState.currentInput = sciState.currentInput.slice(0, -1).trimEnd();
    if (!sciState.currentInput) sciState.currentInput = '0';
  } else {
    sciState.currentInput = '0';
  }
  updateSciDisplay();
}

function sciFunc(fn) {
  try {
    let x = parseFloat(sciState.currentInput);
    if (isNaN(x)) return;

    let res = 0;
    const toRad = sciState.isDegMode ? (x * Math.PI / 180) : x;

    switch (fn) {
      case 'sin': res = Math.sin(toRad); break;
      case 'cos': res = Math.cos(toRad); break;
      case 'tan': 
        if (sciState.isDegMode && Math.abs(x % 180) === 90) { res = 'Undefined'; }
        else { res = Math.tan(toRad); }
        break;
      case 'ln': res = x <= 0 ? 'Error' : Math.log(x); break;
      case 'log': res = x <= 0 ? 'Error' : Math.log10(x); break;
      case 'sqrt': res = x < 0 ? 'Error' : Math.sqrt(x); break;
      case 'square': res = Math.pow(x, 2); break;
      case 'recip': res = x === 0 ? 'Error' : (1 / x); break;
      case 'abs': res = Math.abs(x); break;
      case 'fact':
        if (x < 0 || !Number.isInteger(x) || x > 170) res = 'Error';
        else res = factorial(x);
        break;
    }

    const rounded = typeof res === 'number' ? roundSmart(res) : res;
    sciState.expressionHistory = `${fn}(${x}) =`;
    sciState.currentInput = String(rounded);
    sciState.freshResult = true;
    updateSciDisplay();
    recordCalculation('scientific', `${fn}(${x})`, rounded);
  } catch (err) {
    sciState.currentInput = 'Error';
    updateSciDisplay();
  }
}

function factorial(n) {
  if (n === 0 || n === 1) return 1;
  let res = 1;
  for (let i = 2; i <= n; i++) res *= i;
  return res;
}

function sciCalculate() {
  try {
    const rawExpr = sciState.currentInput
      .replace(/\^/g, '**')
      .replace(/×/g, '*')
      .replace(/÷/g, '/');

    // Safe mathematical evaluation using simple parser
    if (!/^[0-9+\-*/().\s*]+$/.test(rawExpr)) {
      throw new Error('Invalid formula characters');
    }

    // Evaluate mathematical expression safely
    const evalResult = Function(`'use strict'; return (${rawExpr})`)();
    const finalResult = roundSmart(evalResult);

    sciState.expressionHistory = `${sciState.currentInput} =`;
    recordCalculation('scientific', sciState.currentInput, finalResult);
    sciState.currentInput = String(finalResult);
    sciState.freshResult = true;
    updateSciDisplay();
  } catch (e) {
    sciState.currentInput = 'Error';
    updateSciDisplay();
  }
}

/* ==========================================================================
   3. PERCENTAGE CALCULATOR
   ========================================================================== */
let activePercentMode = 'mode1';

function switchPercentMode(mode, btn) {
  activePercentMode = mode;
  document.querySelectorAll('#pane-percentage .sub-tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');

  document.getElementById('pct-sub-mode1').style.display = mode === 'mode1' ? 'block' : 'none';
  document.getElementById('pct-sub-mode2').style.display = mode === 'mode2' ? 'block' : 'none';
  document.getElementById('pct-sub-mode3').style.display = mode === 'mode3' ? 'block' : 'none';

  calcPercentage();
}

function calcPercentage() {
  const resultLabel = document.getElementById('pctResultLabel');
  const resultVal = document.getElementById('pctResultVal');
  const resultSub = document.getElementById('pctResultSub');

  if (activePercentMode === 'mode1') {
    const pct = parseFloat(document.getElementById('pct1_percent')?.value);
    const val = parseFloat(document.getElementById('pct1_value')?.value);

    if (isNaN(pct) || isNaN(val)) {
      resultVal.innerText = '-';
      resultSub.innerText = 'Enter values above';
      return;
    }
    const res = (pct / 100) * val;
    resultLabel.innerText = `${pct}% of ${val}`;
    resultVal.innerText = roundSmart(res);
    resultSub.innerText = `(${pct} ÷ 100) × ${val} = ${roundSmart(res)}`;
    recordCalculation('percentage', `${pct}% of ${val}`, roundSmart(res));
  } else if (activePercentMode === 'mode2') {
    const initial = parseFloat(document.getElementById('pct2_initial')?.value);
    const finalVal = parseFloat(document.getElementById('pct2_final')?.value);

    if (isNaN(initial) || isNaN(finalVal) || initial === 0) {
      resultVal.innerText = '-';
      resultSub.innerText = 'Initial value cannot be zero or empty';
      return;
    }

    const diff = finalVal - initial;
    const pctChange = (diff / Math.abs(initial)) * 100;
    const isIncrease = diff >= 0;

    resultLabel.innerText = isIncrease ? 'Percentage Increase' : 'Percentage Decrease';
    resultVal.innerText = `${isIncrease ? '+' : ''}${roundSmart(pctChange)}%`;
    resultVal.style.color = isIncrease ? 'var(--success)' : 'var(--danger)';
    resultSub.innerText = `Absolute difference: ${roundSmart(diff)} (from ${initial} to ${finalVal})`;
    recordCalculation('percentage', `% Change: ${initial} to ${finalVal}`, `${roundSmart(pctChange)}%`);
  } else if (activePercentMode === 'mode3') {
    const v1 = parseFloat(document.getElementById('pct3_val1')?.value);
    const v2 = parseFloat(document.getElementById('pct3_val2')?.value);

    if (isNaN(v1) || isNaN(v2) || (v1 + v2) === 0) {
      resultVal.innerText = '-';
      resultSub.innerText = 'Sum of values cannot be zero';
      return;
    }

    const diff = Math.abs(v1 - v2);
    const avg = (v1 + v2) / 2;
    const pctDiff = (diff / avg) * 100;

    resultLabel.innerText = 'Relative Difference';
    resultVal.innerText = `${roundSmart(pctDiff)}%`;
    resultVal.style.color = 'var(--primary)';
    resultSub.innerText = `|${v1} - ${v2}| ÷ Average(${v1}, ${v2}) × 100`;
    recordCalculation('percentage', `% Diff: ${v1} & ${v2}`, `${roundSmart(pctDiff)}%`);
  }
}

function resetPercentage() {
  document.getElementById('pct1_percent').value = '';
  document.getElementById('pct1_value').value = '';
  document.getElementById('pct2_initial').value = '';
  document.getElementById('pct2_final').value = '';
  document.getElementById('pct3_val1').value = '';
  document.getElementById('pct3_val2').value = '';
  calcPercentage();
  showToast('Percentage calculator cleared');
}

/* ==========================================================================
   4. AGE CALCULATOR
   ========================================================================== */
function initDefaultCalculatorStates() {
  // Set Age calculator defaults to today
  const todayStr = new Date().toISOString().split('T')[0];
  const targetDateInput = document.getElementById('ageTargetDate');
  const dobInput = document.getElementById('ageDob');
  if (targetDateInput) targetDateInput.value = todayStr;
  if (dobInput) dobInput.value = '2000-01-01';

  // Date diff defaults
  const dateStart = document.getElementById('dateStart');
  const dateEnd = document.getElementById('dateEnd');
  if (dateStart) dateStart.value = todayStr;
  if (dateEnd) {
    const nextWeek = new Date();
    nextWeek.setDate(nextWeek.getDate() + 30);
    dateEnd.value = nextWeek.toISOString().split('T')[0];
  }

  // CGPA Default Rows
  initCgpaRows();
  // GPA Default Rows
  initGpaRows();
  // Unit converter dropdowns
  initUnitOptions('length');
}

function calcAge() {
  const dobVal = document.getElementById('ageDob')?.value;
  const targetVal = document.getElementById('ageTargetDate')?.value;
  const mainResult = document.getElementById('ageMainResult');
  const subtext = document.getElementById('ageSubtext');
  const nextBirthday = document.getElementById('ageNextBirthday');
  const totalDays = document.getElementById('ageTotalDays');
  const totalWeeks = document.getElementById('ageTotalWeeks');
  const totalHours = document.getElementById('ageTotalHours');

  if (!dobVal || !targetVal) return;

  const birthDate = new Date(dobVal);
  const targetDate = new Date(targetVal);

  if (targetDate < birthDate) {
    mainResult.innerText = 'Invalid Dates';
    subtext.innerText = 'Date of birth cannot be in the future of target date';
    return;
  }

  let years = targetDate.getFullYear() - birthDate.getFullYear();
  let months = targetDate.getMonth() - birthDate.getMonth();
  let days = targetDate.getDate() - birthDate.getDate();

  if (days < 0) {
    months--;
    const prevMonthDays = new Date(targetDate.getFullYear(), targetDate.getMonth(), 0).getDate();
    days += prevMonthDays;
  }

  if (months < 0) {
    years--;
    months += 12;
  }

  const ageString = `${years} Years, ${months} Months, ${days} Days`;
  mainResult.innerText = ageString;
  subtext.innerText = `Born on ${birthDate.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}`;

  // Lifetime counts
  const diffTime = targetDate.getTime() - birthDate.getTime();
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  totalDays.innerText = diffDays.toLocaleString() + ' days';
  totalWeeks.innerText = Math.floor(diffDays / 7).toLocaleString() + ' weeks';
  totalHours.innerText = (diffDays * 24).toLocaleString() + ' hours';

  // Next Birthday Countdown
  let nextBdayYear = targetDate.getFullYear();
  let nextBday = new Date(nextBdayYear, birthDate.getMonth(), birthDate.getDate());
  if (nextBday < targetDate) {
    nextBday.setFullYear(nextBdayYear + 1);
  }
  const daysUntilBday = Math.ceil((nextBday - targetDate) / (1000 * 60 * 60 * 24));
  nextBirthday.innerText = `${daysUntilBday} days remaining (${nextBday.toLocaleDateString(undefined, { weekday: 'short' })})`;

  recordCalculation('age', `DOB: ${dobVal}`, ageString);
}

function resetAge() {
  document.getElementById('ageDob').value = '2000-01-01';
  document.getElementById('ageTargetDate').value = new Date().toISOString().split('T')[0];
  calcAge();
}

/* ==========================================================================
   5. BMI CALCULATOR
   ========================================================================== */
let activeBmiUnit = 'metric';

function switchBmiUnit(unit, btn) {
  activeBmiUnit = unit;
  document.querySelectorAll('#pane-bmi .sub-tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');

  document.getElementById('bmiMetricInputs').style.display = unit === 'metric' ? 'block' : 'none';
  document.getElementById('bmiImperialInputs').style.display = unit === 'imperial' ? 'block' : 'none';

  calcBMI();
}

function calcBMI() {
  let bmi = 0;
  let minWeight = 0;
  let maxWeight = 0;
  let unitLabel = 'kg';

  if (activeBmiUnit === 'metric') {
    const cm = parseFloat(document.getElementById('bmiHeightCm')?.value);
    const kg = parseFloat(document.getElementById('bmiWeightKg')?.value);

    if (isNaN(cm) || isNaN(kg) || cm <= 0 || kg <= 0) return;

    const meters = cm / 100;
    bmi = kg / (meters * meters);
    minWeight = roundSmart(18.5 * meters * meters);
    maxWeight = roundSmart(24.9 * meters * meters);
    unitLabel = 'kg';
  } else {
    const ft = parseFloat(document.getElementById('bmiHeightFt')?.value) || 0;
    const inch = parseFloat(document.getElementById('bmiHeightIn')?.value) || 0;
    const lbs = parseFloat(document.getElementById('bmiWeightLbs')?.value);

    const totalInches = (ft * 12) + inch;
    if (totalInches <= 0 || isNaN(lbs) || lbs <= 0) return;

    bmi = (lbs * 703) / (totalInches * totalInches);
    minWeight = roundSmart((18.5 * totalInches * totalInches) / 703);
    maxWeight = roundSmart((24.9 * totalInches * totalInches) / 703);
    unitLabel = 'lbs';
  }

  const bmiFormatted = bmi.toFixed(1);
  const bmiValEl = document.getElementById('bmiVal');
  const badgeSlot = document.getElementById('bmiBadgeSlot');
  const pointer = document.getElementById('bmiGaugePointer');
  const weightRange = document.getElementById('bmiHealthyWeightRange');

  if (bmiValEl) bmiValEl.innerText = bmiFormatted;
  if (weightRange) weightRange.innerText = `${minWeight} - ${maxWeight} ${unitLabel}`;

  let category = 'Normal';
  let badgeClass = 'normal';
  if (bmi < 18.5) {
    category = 'Underweight';
    badgeClass = 'underweight';
  } else if (bmi <= 24.9) {
    category = 'Normal Weight';
    badgeClass = 'normal';
  } else if (bmi <= 29.9) {
    category = 'Overweight';
    badgeClass = 'overweight';
  } else {
    category = 'Obese';
    badgeClass = 'obese';
  }

  if (badgeSlot) {
    badgeSlot.innerHTML = `<span class="bmi-badge ${badgeClass}">${category}</span>`;
  }

  // Pointer position clamped between 0% and 100% (map 12 to 40 BMI)
  let percent = ((bmi - 12) / (40 - 12)) * 100;
  percent = Math.max(2, Math.min(98, percent));
  if (pointer) pointer.style.left = `${percent}%`;

  recordCalculation('bmi', `BMI Result (${category})`, `${bmiFormatted} kg/m²`);
}

function resetBMI() {
  document.getElementById('bmiHeightCm').value = '';
  document.getElementById('bmiWeightKg').value = '';
  document.getElementById('bmiHeightFt').value = '';
  document.getElementById('bmiHeightIn').value = '';
  document.getElementById('bmiWeightLbs').value = '';
  document.getElementById('bmiVal').innerText = '--';
  document.getElementById('bmiBadgeSlot').innerHTML = '<span class="bmi-badge normal">Enter height &amp; weight</span>';
  document.getElementById('bmiGaugePointer').style.left = '0%';
  document.getElementById('bmiHealthyWeightRange').innerText = '-';
}

/* ==========================================================================
   6. LOAN / EMI CALCULATOR
   ========================================================================== */
function calcLoan() {
  const principal = parseFloat(document.getElementById('loanAmount')?.value);
  const rate = parseFloat(document.getElementById('loanRate')?.value);
  const tenure = parseFloat(document.getElementById('loanTenure')?.value);
  const tenureType = document.getElementById('loanTenureType')?.value;

  if (isNaN(principal) || isNaN(rate) || isNaN(tenure) || principal <= 0 || tenure <= 0) return;

  const totalMonths = tenureType === 'years' ? tenure * 12 : tenure;
  const monthlyRate = rate / (12 * 100);

  let emi = 0;
  if (monthlyRate === 0) {
    emi = principal / totalMonths;
  } else {
    const factor = Math.pow(1 + monthlyRate, totalMonths);
    emi = (principal * monthlyRate * factor) / (factor - 1);
  }

  const totalPayment = emi * totalMonths;
  const totalInterest = totalPayment - principal;

  const emiVal = document.getElementById('loanEmiVal');
  const totalPrincEl = document.getElementById('loanTotalPrincipal');
  const totalIntEl = document.getElementById('loanTotalInterest');
  const totalAmtEl = document.getElementById('loanTotalAmount');
  const princBar = document.getElementById('loanPrincipalBar');
  const intBar = document.getElementById('loanInterestBar');
  const princPct = document.getElementById('loanPrincPct');
  const intPct = document.getElementById('loanIntPct');
  const tenureSub = document.getElementById('loanTenureSub');

  if (emiVal) emiVal.innerText = formatMoney(emi);
  if (totalPrincEl) totalPrincEl.innerText = formatMoney(principal);
  if (totalIntEl) totalIntEl.innerText = formatMoney(totalInterest);
  if (totalAmtEl) totalAmtEl.innerText = formatMoney(totalPayment);
  if (tenureSub) tenureSub.innerText = `For ${totalMonths} monthly payments`;

  const princRatio = Math.round((principal / totalPayment) * 100);
  const intRatio = 100 - princRatio;

  if (princBar) princBar.style.width = `${princRatio}%`;
  if (intBar) intBar.style.width = `${intRatio}%`;
  if (princPct) princPct.innerText = `${princRatio}%`;
  if (intPct) intPct.innerText = `${intRatio}%`;

  recordCalculation('loan', `Loan EMI for ${formatMoney(principal)} @ ${rate}%`, `${formatMoney(emi)} / mo`);
}

function resetLoan() {
  document.getElementById('loanAmount').value = '';
  document.getElementById('loanRate').value = '';
  document.getElementById('loanTenure').value = '';
  document.getElementById('loanEmiVal').innerText = '0.00';
  document.getElementById('loanTotalPrincipal').innerText = '0.00';
  document.getElementById('loanTotalInterest').innerText = '0.00';
  document.getElementById('loanTotalAmount').innerText = '0.00';
}

/* ==========================================================================
   7. SIMPLE INTEREST CALCULATOR
   ========================================================================== */
function calcSimpleInterest() {
  const p = parseFloat(document.getElementById('siPrincipal')?.value);
  const r = parseFloat(document.getElementById('siRate')?.value);
  let t = parseFloat(document.getElementById('siTime')?.value);
  const unit = document.getElementById('siTimeUnit')?.value;

  if (isNaN(p) || isNaN(r) || isNaN(t) || p < 0) return;
  if (unit === 'months') t = t / 12;

  const si = (p * r * t) / 100;
  const total = p + si;

  const interestVal = document.getElementById('siInterestVal');
  const principalStat = document.getElementById('siPrincipalStat');
  const totalVal = document.getElementById('siTotalVal');

  if (interestVal) interestVal.innerText = formatMoney(si);
  if (principalStat) principalStat.innerText = formatMoney(p);
  if (totalVal) totalVal.innerText = formatMoney(total);

  recordCalculation('simple-interest', `SI on ${formatMoney(p)} @ ${r}% for ${t} yrs`, formatMoney(si));
}

function resetSimpleInterest() {
  document.getElementById('siPrincipal').value = '';
  document.getElementById('siRate').value = '';
  document.getElementById('siTime').value = '';
  document.getElementById('siInterestVal').innerText = '0.00';
  document.getElementById('siPrincipalStat').innerText = '0.00';
  document.getElementById('siTotalVal').innerText = '0.00';
}

/* ==========================================================================
   8. COMPOUND INTEREST CALCULATOR
   ========================================================================== */
function calcCompoundInterest() {
  const p = parseFloat(document.getElementById('ciPrincipal')?.value);
  const r = parseFloat(document.getElementById('ciRate')?.value);
  const t = parseFloat(document.getElementById('ciTime')?.value);
  const n = parseInt(document.getElementById('ciFrequency')?.value) || 12;
  const pmt = parseFloat(document.getElementById('ciMonthlyDeposit')?.value) || 0;

  if (isNaN(p) || isNaN(r) || isNaN(t) || p < 0 || t <= 0) return;

  const rateDec = r / 100;
  // Principal growth
  const compoundPrincipal = p * Math.pow(1 + (rateDec / n), n * t);
  // Future value of a series of monthly deposits (PMT)
  let futureDeposits = 0;
  if (pmt > 0) {
    const monthlyRate = rateDec / 12;
    const totalMonths = t * 12;
    if (monthlyRate > 0) {
      futureDeposits = pmt * ((Math.pow(1 + monthlyRate, totalMonths) - 1) / monthlyRate);
    } else {
      futureDeposits = pmt * totalMonths;
    }
  }

  const futureValue = compoundPrincipal + futureDeposits;
  const totalInvested = p + (pmt * 12 * t);
  const totalInterest = futureValue - totalInvested;
  const multiplier = totalInvested > 0 ? (futureValue / totalInvested).toFixed(2) : '1.00';

  document.getElementById('ciFutureVal').innerText = formatMoney(futureValue);
  document.getElementById('ciTotalInvested').innerText = formatMoney(totalInvested);
  document.getElementById('ciTotalInterest').innerText = formatMoney(totalInterest);
  document.getElementById('ciGrowthMultiplier').innerText = `Growth: ${multiplier}x`;

  recordCalculation('compound-interest', `CI ${formatMoney(p)} @ ${r}% for ${t} yrs`, formatMoney(futureValue));
}

function resetCompoundInterest() {
  document.getElementById('ciPrincipal').value = '';
  document.getElementById('ciRate').value = '';
  document.getElementById('ciTime').value = '';
  document.getElementById('ciMonthlyDeposit').value = '';
  document.getElementById('ciFutureVal').innerText = '0.00';
  document.getElementById('ciTotalInvested').innerText = '0.00';
  document.getElementById('ciTotalInterest').innerText = '0.00';
}

/* ==========================================================================
   9. GST CALCULATOR
   ========================================================================== */
let activeGstMode = 'add';

function switchGstMode(mode, btn) {
  activeGstMode = mode;
  document.querySelectorAll('#pane-gst .sub-tabs-bar .sub-tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');

  const label = document.getElementById('gstPrimaryLabel');
  if (label) {
    label.innerText = mode === 'add' ? 'Gross Amount (Post-Tax)' : 'Net Amount (Pre-Tax)';
  }
  calcGST();
}

function setGstSlab(slab) {
  const rateInput = document.getElementById('gstCustomRate');
  if (rateInput) rateInput.value = slab;
  calcGST();
}

function calcGST() {
  const amount = parseFloat(document.getElementById('gstAmount')?.value);
  const rate = parseFloat(document.getElementById('gstCustomRate')?.value);

  if (isNaN(amount) || isNaN(rate) || amount < 0) return;

  let net = 0;
  let gst = 0;
  let gross = 0;

  if (activeGstMode === 'add') {
    net = amount;
    gst = (net * rate) / 100;
    gross = net + gst;
  } else {
    gross = amount;
    net = gross / (1 + (rate / 100));
    gst = gross - net;
  }

  const cgst = gst / 2;
  const sgst = gst / 2;

  document.getElementById('gstGrossVal').innerText = formatMoney(activeGstMode === 'add' ? gross : net);
  document.getElementById('gstNetVal').innerText = formatMoney(net);
  document.getElementById('gstTotalTaxVal').innerText = formatMoney(gst);
  document.getElementById('gstCgstVal').innerText = formatMoney(cgst);
  document.getElementById('gstSgstVal').innerText = formatMoney(sgst);

  recordCalculation('gst', `GST (${rate}%) on ${formatMoney(amount)}`, formatMoney(gross));
}

function resetGST() {
  document.getElementById('gstAmount').value = '';
  document.getElementById('gstGrossVal').innerText = '0.00';
  document.getElementById('gstNetVal').innerText = '0.00';
  document.getElementById('gstTotalTaxVal').innerText = '0.00';
  document.getElementById('gstCgstVal').innerText = '0.00';
  document.getElementById('gstSgstVal').innerText = '0.00';
}

/* ==========================================================================
   10. DISCOUNT CALCULATOR
   ========================================================================== */
function calcDiscount() {
  const orig = parseFloat(document.getElementById('discOriginalPrice')?.value);
  const discRate = parseFloat(document.getElementById('discPrimaryRate')?.value);
  const extraRate = parseFloat(document.getElementById('discExtraRate')?.value) || 0;
  const taxRate = parseFloat(document.getElementById('discTaxRate')?.value) || 0;

  if (isNaN(orig) || isNaN(discRate) || orig < 0) return;

  const afterPrimary = orig * (1 - (discRate / 100));
  const afterStacked = afterPrimary * (1 - (extraRate / 100));
  const taxAmount = afterStacked * (taxRate / 100);
  const finalPrice = afterStacked + taxAmount;
  const totalSavings = orig - afterStacked;
  const percentSaved = orig > 0 ? ((totalSavings / orig) * 100).toFixed(1) : 0;

  document.getElementById('discFinalVal').innerText = formatMoney(finalPrice);
  document.getElementById('discOrigVal').innerText = formatMoney(orig);
  document.getElementById('discSavingsVal').innerText = formatMoney(totalSavings);
  document.getElementById('discTaxAmount').innerText = formatMoney(taxAmount);
  document.getElementById('discPercentSaved').innerText = `You save ${percentSaved}% in total`;

  recordCalculation('discount', `Discount ${discRate}% on ${formatMoney(orig)}`, formatMoney(finalPrice));
}

function resetDiscount() {
  document.getElementById('discOriginalPrice').value = '';
  document.getElementById('discPrimaryRate').value = '';
  document.getElementById('discExtraRate').value = '';
  document.getElementById('discTaxRate').value = '';
  document.getElementById('discFinalVal').innerText = '0.00';
  document.getElementById('discOrigVal').innerText = '0.00';
  document.getElementById('discSavingsVal').innerText = '0.00';
  document.getElementById('discTaxAmount').innerText = '0.00';
}

/* ==========================================================================
   11. PROFIT & LOSS CALCULATOR
   ========================================================================== */
function calcProfitLoss() {
  const cp = parseFloat(document.getElementById('plCostPrice')?.value);
  const sp = parseFloat(document.getElementById('plSellingPrice')?.value);

  if (isNaN(cp) || isNaN(sp) || cp <= 0) return;

  const diff = sp - cp;
  const isProfit = diff > 0;
  const isLoss = diff < 0;

  const netPct = (Math.abs(diff) / cp) * 100;
  const markup = ((sp - cp) / cp) * 100;
  const margin = sp > 0 ? ((sp - cp) / sp) * 100 : 0;

  const statusLabel = document.getElementById('plStatusLabel');
  const netVal = document.getElementById('plNetVal');
  const pctVal = document.getElementById('plPercentVal');

  if (isProfit) {
    statusLabel.innerText = 'Net Profit';
    netVal.innerText = `+${formatMoney(diff)}`;
    netVal.style.color = 'var(--success)';
    pctVal.innerText = `${roundSmart(netPct)}% Profit`;
  } else if (isLoss) {
    statusLabel.innerText = 'Net Loss';
    netVal.innerText = `-${formatMoney(Math.abs(diff))}`;
    netVal.style.color = 'var(--danger)';
    pctVal.innerText = `${roundSmart(netPct)}% Loss`;
  } else {
    statusLabel.innerText = 'Break Even';
    netVal.innerText = '0.00';
    netVal.style.color = 'var(--text-main)';
    pctVal.innerText = '0% No Profit / No Loss';
  }

  document.getElementById('plMarkupVal').innerText = `${roundSmart(markup)}%`;
  document.getElementById('plMarginVal').innerText = `${roundSmart(margin)}%`;

  recordCalculation('profit-loss', `P&L: CP=${formatMoney(cp)}, SP=${formatMoney(sp)}`, `${netVal.innerText} (${roundSmart(netPct)}%)`);
}

function resetProfitLoss() {
  document.getElementById('plCostPrice').value = '';
  document.getElementById('plSellingPrice').value = '';
  document.getElementById('plNetVal').innerText = '0.00';
  document.getElementById('plPercentVal').innerText = '0.00%';
  document.getElementById('plMarkupVal').innerText = '0.00%';
  document.getElementById('plMarginVal').innerText = '0.00%';
}

/* ==========================================================================
   12. TIME CALCULATOR
   ========================================================================== */
let activeTimeMode = 'duration';

function switchTimeMode(mode, btn) {
  activeTimeMode = mode;
  document.querySelectorAll('#pane-time .sub-tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');

  document.getElementById('timeModeDuration').style.display = mode === 'duration' ? 'block' : 'none';
  document.getElementById('timeModeAdd').style.display = mode === 'add' ? 'block' : 'none';

  calcTime();
}

function calcTime() {
  if (activeTimeMode === 'duration') {
    const startStr = document.getElementById('timeStart')?.value;
    const endStr = document.getElementById('timeEnd')?.value;

    if (!startStr || !endStr) return;

    const [sh, sm] = startStr.split(':').map(Number);
    const [eh, em] = endStr.split(':').map(Number);

    let startMins = sh * 60 + sm;
    let endMins = eh * 60 + em;

    // Crosses midnight
    if (endMins < startMins) endMins += 24 * 60;

    const totalMins = endMins - startMins;
    const hrs = Math.floor(totalMins / 60);
    const mins = totalMins % 60;

    document.getElementById('timeResultLabel').innerText = 'Total Elapsed Duration';
    document.getElementById('timeMainVal').innerText = `${hrs} hrs ${mins} mins`;
    document.getElementById('timeSubVal').innerText = `${totalMins} total minutes`;
    document.getElementById('timeTotalMins').innerText = `${totalMins} mins`;
    document.getElementById('timeTotalSecs').innerText = `${(totalMins * 60).toLocaleString()} secs`;

    recordCalculation('time', `Duration: ${startStr} to ${endStr}`, `${hrs}h ${mins}m`);
  } else {
    const baseStr = document.getElementById('timeBase')?.value;
    const op = document.getElementById('timeAddOp')?.value;
    const addHrs = parseInt(document.getElementById('timeHours')?.value) || 0;
    const addMins = parseInt(document.getElementById('timeMinutes')?.value) || 0;

    if (!baseStr) return;

    const [bh, bm] = baseStr.split(':').map(Number);
    let totalBaseMins = bh * 60 + bm;
    const deltaMins = addHrs * 60 + addMins;

    let finalMins = op === 'add' ? totalBaseMins + deltaMins : totalBaseMins - deltaMins;
    // Modulo 24 hours
    finalMins = ((finalMins % (24 * 60)) + (24 * 60)) % (24 * 60);

    const fh = Math.floor(finalMins / 60);
    const fm = finalMins % 60;
    const timeFormatted = `${String(fh).padStart(2, '0')}:${String(fm).padStart(2, '0')}`;

    document.getElementById('timeResultLabel').innerText = 'Resulting Time';
    document.getElementById('timeMainVal').innerText = timeFormatted;
    document.getElementById('timeSubVal').innerText = `${baseStr} ${op === 'add' ? '+' : '-'} ${addHrs}h ${addMins}m`;

    recordCalculation('time', `${baseStr} ${op === 'add' ? '+' : '-'} ${addHrs}h ${addMins}m`, timeFormatted);
  }
}

function resetTime() {
  document.getElementById('timeStart').value = '09:00';
  document.getElementById('timeEnd').value = '17:30';
  calcTime();
}

/* ==========================================================================
   13. DATE DIFFERENCE CALCULATOR
   ========================================================================== */
function calcDateDiff() {
  const startVal = document.getElementById('dateStart')?.value;
  const endVal = document.getElementById('dateEnd')?.value;
  const includeEnd = document.getElementById('dateIncludeEnd')?.checked;

  if (!startVal || !endVal) return;

  const d1 = new Date(startVal);
  const d2 = new Date(endVal);

  if (d2 < d1) {
    document.getElementById('dateDiffDaysVal').innerText = 'Invalid Range';
    document.getElementById('dateDiffYmdVal').innerText = 'End date cannot be prior to start date';
    return;
  }

  const timeDiff = d2.getTime() - d1.getTime();
  let totalDays = Math.round(timeDiff / (1000 * 60 * 60 * 24));
  if (includeEnd) totalDays += 1;

  // Breakdown in years, months, days
  let cur = new Date(d1);
  let target = new Date(d2);
  let y = target.getFullYear() - cur.getFullYear();
  let m = target.getMonth() - cur.getMonth();
  let d = target.getDate() - cur.getDate();

  if (d < 0) {
    m--;
    const prevMonthDays = new Date(target.getFullYear(), target.getMonth(), 0).getDate();
    d += prevMonthDays;
  }
  if (m < 0) {
    y--;
    m += 12;
  }

  // Count Business Days (Monday to Friday)
  let businessDays = 0;
  let weekendDays = 0;
  let tempDate = new Date(d1);
  const maxLoops = totalDays + (includeEnd ? 0 : 0);

  for (let i = 0; i < (includeEnd ? totalDays : totalDays); i++) {
    const dayOfWeek = tempDate.getDay();
    if (dayOfWeek === 0 || dayOfWeek === 6) {
      weekendDays++;
    } else {
      businessDays++;
    }
    tempDate.setDate(tempDate.getDate() + 1);
  }

  const weeks = (totalDays / 7).toFixed(1);

  document.getElementById('dateDiffDaysVal').innerText = `${totalDays.toLocaleString()} days`;
  document.getElementById('dateDiffYmdVal').innerText = `${y} years, ${m} months, ${d} days`;
  document.getElementById('dateDiffBusinessDays').innerText = `${businessDays.toLocaleString()} days`;
  document.getElementById('dateDiffWeekendDays').innerText = `${weekendDays.toLocaleString()} days`;
  document.getElementById('dateDiffWeeks').innerText = `${weeks} weeks`;

  recordCalculation('date-diff', `From ${startVal} to ${endVal}`, `${totalDays} days`);
}

function resetDateDiff() {
  document.getElementById('dateStart').value = new Date().toISOString().split('T')[0];
  const nextDate = new Date();
  nextDate.setDate(nextDate.getDate() + 30);
  document.getElementById('dateEnd').value = nextDate.toISOString().split('T')[0];
  document.getElementById('dateIncludeEnd').checked = false;
  calcDateDiff();
}

/* ==========================================================================
   14. UNIT CONVERTER
   ========================================================================== */
const UNIT_DEFINITIONS = {
  length: {
    base: 'm',
    units: {
      'm': { name: 'Meters (m)', factor: 1 },
      'km': { name: 'Kilometers (km)', factor: 1000 },
      'cm': { name: 'Centimeters (cm)', factor: 0.01 },
      'mm': { name: 'Millimeters (mm)', factor: 0.001 },
      'mi': { name: 'Miles (mi)', factor: 1609.344 },
      'yd': { name: 'Yards (yd)', factor: 0.9144 },
      'ft': { name: 'Feet (ft)', factor: 0.3048 },
      'in': { name: 'Inches (in)', factor: 0.0254 }
    }
  },
  weight: {
    base: 'kg',
    units: {
      'kg': { name: 'Kilograms (kg)', factor: 1 },
      'g': { name: 'Grams (g)', factor: 0.001 },
      'mg': { name: 'Milligrams (mg)', factor: 0.000001 },
      'lb': { name: 'Pounds (lbs)', factor: 0.45359237 },
      'oz': { name: 'Ounces (oz)', factor: 0.0283495 },
      'ton': { name: 'Metric Tons (t)', factor: 1000 }
    }
  },
  temp: {
    units: {
      'c': { name: 'Celsius (°C)' },
      'f': { name: 'Fahrenheit (°F)' },
      'k': { name: 'Kelvin (K)' }
    }
  },
  area: {
    base: 'sqm',
    units: {
      'sqm': { name: 'Square Meters (m²)', factor: 1 },
      'sqkm': { name: 'Square Kilometers (km²)', factor: 1000000 },
      'sqft': { name: 'Square Feet (ft²)', factor: 0.092903 },
      'acre': { name: 'Acres', factor: 4046.86 },
      'hectare': { name: 'Hectares', factor: 10000 }
    }
  },
  volume: {
    base: 'liter',
    units: {
      'liter': { name: 'Liters (L)', factor: 1 },
      'ml': { name: 'Milliliters (mL)', factor: 0.001 },
      'cbm': { name: 'Cubic Meters (m³)', factor: 1000 },
      'gal': { name: 'Gallons US (gal)', factor: 3.78541 },
      'floz': { name: 'Fluid Ounces US', factor: 0.0295735 }
    }
  }
};

let activeUnitCategory = 'length';

function switchUnitType(cat, btn) {
  activeUnitCategory = cat;
  document.querySelectorAll('#pane-unit-converter .sub-tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  initUnitOptions(cat);
  convertUnits();
}

function initUnitOptions(cat) {
  const fromSelect = document.getElementById('unitFromSelect');
  const toSelect = document.getElementById('unitToSelect');
  if (!fromSelect || !toSelect) return;

  const def = UNIT_DEFINITIONS[cat];
  const keys = Object.keys(def.units);

  fromSelect.innerHTML = keys.map(k => `<option value="${k}">${def.units[k].name}</option>`).join('');
  toSelect.innerHTML = keys.map(k => `<option value="${k}">${def.units[k].name}</option>`).join('');

  if (keys.length > 1) {
    toSelect.selectedIndex = 1;
  }
}

function swapUnits() {
  const fromSelect = document.getElementById('unitFromSelect');
  const toSelect = document.getElementById('unitToSelect');
  if (!fromSelect || !toSelect) return;

  const temp = fromSelect.value;
  fromSelect.value = toSelect.value;
  toSelect.value = temp;
  convertUnits();
}

function convertUnits() {
  const inputVal = parseFloat(document.getElementById('unitFromVal')?.value);
  const fromKey = document.getElementById('unitFromSelect')?.value;
  const toKey = document.getElementById('unitToSelect')?.value;
  const convertedVal = document.getElementById('unitConvertedVal');
  const formulaText = document.getElementById('unitFormulaText');

  if (isNaN(inputVal)) {
    if (convertedVal) convertedVal.innerText = '-';
    return;
  }

  let result = 0;
  const cat = activeUnitCategory;

  if (cat === 'temp') {
    // Temperature conversion
    let c = 0;
    if (fromKey === 'c') c = inputVal;
    else if (fromKey === 'f') c = (inputVal - 32) * (5 / 9);
    else if (fromKey === 'k') c = inputVal - 273.15;

    if (toKey === 'c') result = c;
    else if (toKey === 'f') result = (c * (9 / 5)) + 32;
    else if (toKey === 'k') result = c + 273.15;

    formulaText.innerText = `${inputVal} ${fromKey.toUpperCase()} = ${roundSmart(result)} ${toKey.toUpperCase()}`;
  } else {
    const def = UNIT_DEFINITIONS[cat];
    const fromFactor = def.units[fromKey].factor;
    const toFactor = def.units[toKey].factor;

    // Convert to base, then to target
    const baseValue = inputVal * fromFactor;
    result = baseValue / toFactor;

    formulaText.innerText = `Multiplied by ${(fromFactor / toFactor).toPrecision(5)}`;
  }

  const rounded = roundSmart(result);
  convertedVal.innerText = `${rounded}`;

  recordCalculation('unit-converter', `Convert ${inputVal} ${fromKey} to ${toKey}`, `${rounded}`);
}

function resetUnits() {
  document.getElementById('unitFromVal').value = '1';
  convertUnits();
}

/* ==========================================================================
   15. CURRENCY CONVERTER
   ========================================================================== */
const CURRENCY_RATES_BASE_USD = {
  'USD': 1.0,
  'EUR': 0.92,
  'GBP': 0.78,
  'INR': 83.50,
  'JPY': 155.20,
  'CAD': 1.36,
  'AUD': 1.50,
  'CHF': 0.90,
  'CNY': 7.24,
  'AED': 3.67,
  'SGD': 1.35
};

function swapCurrencies() {
  const from = document.getElementById('currFromSelect');
  const to = document.getElementById('currToSelect');
  if (!from || !to) return;
  const temp = from.value;
  from.value = to.value;
  to.value = temp;
  convertCurrency();
}

function convertCurrency() {
  const amount = parseFloat(document.getElementById('currAmount')?.value);
  const from = document.getElementById('currFromSelect')?.value;
  const to = document.getElementById('currToSelect')?.value;

  if (isNaN(amount) || amount < 0) return;

  const rateFrom = CURRENCY_RATES_BASE_USD[from] || 1;
  const rateTo = CURRENCY_RATES_BASE_USD[to] || 1;

  // Amount in USD = amount / rateFrom, then in target = usd * rateTo
  const converted = (amount / rateFrom) * rateTo;
  const unitRate = rateTo / rateFrom;
  const inverseRate = rateFrom / rateTo;

  document.getElementById('currConversionRate').innerText = `1 ${from} = ${unitRate.toFixed(4)} ${to}`;
  document.getElementById('currResultVal').innerText = `${getCurrencySymbol(to)}${formatMoney(converted)}`;
  document.getElementById('currInverseRate').innerText = `1 ${to} = ${inverseRate.toFixed(4)} ${from}`;

  recordCalculation('currency', `${amount} ${from} to ${to}`, `${formatMoney(converted)} ${to}`);
}

function getCurrencySymbol(code) {
  switch (code) {
    case 'USD': case 'CAD': case 'AUD': case 'SGD': return '$';
    case 'EUR': return '€';
    case 'GBP': return '£';
    case 'INR': return '₹';
    case 'JPY': case 'CNY': return '¥';
    case 'AED': return 'د.إ ';
    default: return '';
  }
}

function resetCurrency() {
  document.getElementById('currAmount').value = '100';
  convertCurrency();
}

/* ==========================================================================
   16. CGPA CALCULATOR
   ========================================================================== */
let cgpaSemesterCount = 0;

function initCgpaRows() {
  const container = document.getElementById('cgpaSemestersContainer');
  if (!container) return;
  container.innerHTML = '';
  cgpaSemesterCount = 0;

  // Add 4 initial semester rows
  for (let i = 1; i <= 4; i++) {
    addCgpaSemesterRow();
  }
}

function addCgpaSemesterRow() {
  cgpaSemesterCount++;
  const container = document.getElementById('cgpaSemestersContainer');
  if (!container) return;

  const row = document.createElement('div');
  row.className = 'dynamic-row';
  row.id = `cgpaRow_${cgpaSemesterCount}`;
  row.innerHTML = `
    <div>
      <input type="text" class="form-input" value="Semester ${cgpaSemesterCount}" style="height: 2.4rem; font-size: 0.88rem;" aria-label="Semester Name">
    </div>
    <div class="input-with-addon">
      <input type="number" step="0.01" class="form-input cgpa-gpa-val" placeholder="SGPA / GPA" oninput="calcCGPA()" style="height: 2.4rem;">
      <span class="input-addon input-addon-right" style="height: 2.4rem; font-size: 0.75rem;">GPA</span>
    </div>
    <div class="input-with-addon">
      <input type="number" step="0.5" class="form-input cgpa-credit-val" value="20" placeholder="Credits" oninput="calcCGPA()" style="height: 2.4rem;">
      <span class="input-addon input-addon-right" style="height: 2.4rem; font-size: 0.75rem;">Cr</span>
    </div>
    <button type="button" class="btn-remove-row" onclick="removeCgpaRow(${cgpaSemesterCount})" title="Delete semester">✕</button>
  `;
  container.appendChild(row);
}

function removeCgpaRow(id) {
  const row = document.getElementById(`cgpaRow_${id}`);
  if (row) {
    row.remove();
    calcCGPA();
  }
}

function calcCGPA() {
  const gpaInputs = document.querySelectorAll('.cgpa-gpa-val');
  const creditInputs = document.querySelectorAll('.cgpa-credit-val');
  const formulaType = document.getElementById('cgpaFormulaType')?.value || '9.5';

  let totalWeightedGpa = 0;
  let totalCredits = 0;
  let count = 0;

  gpaInputs.forEach((gpaInput, index) => {
    const gpa = parseFloat(gpaInput.value);
    const credits = parseFloat(creditInputs[index]?.value) || 0;

    if (!isNaN(gpa) && gpa >= 0 && credits > 0) {
      totalWeightedGpa += (gpa * credits);
      totalCredits += credits;
      count++;
    }
  });

  const resultVal = document.getElementById('cgpaResultVal');
  const classVal = document.getElementById('cgpaClassVal');
  const percentVal = document.getElementById('cgpaPercentVal');
  const totalCreditsVal = document.getElementById('cgpaTotalCredits');

  if (totalCredits === 0) {
    if (resultVal) resultVal.innerText = '0.00';
    if (classVal) classVal.innerText = 'Enter semester GPAs and credits above';
    return;
  }

  const cgpa = totalWeightedGpa / totalCredits;
  const multiplier = parseFloat(formulaType);
  const percentage = formulaType === '9.5' ? (cgpa * 9.5) : (cgpa * 10);

  resultVal.innerText = cgpa.toFixed(2);
  totalCreditsVal.innerText = totalCredits;
  percentVal.innerText = `${percentage.toFixed(1)}%`;

  let standing = 'First Class with Distinction';
  if (cgpa < 6.0) standing = 'Pass Class';
  else if (cgpa < 7.0) standing = 'Second Class';
  else if (cgpa < 8.0) standing = 'First Class';

  classVal.innerText = standing;

  recordCalculation('cgpa', `Overall CGPA (${count} Semesters)`, cgpa.toFixed(2));
}

function resetCGPA() {
  initCgpaRows();
  calcCGPA();
}

/* ==========================================================================
   17. GPA CALCULATOR
   ========================================================================== */
const GRADE_POINTS_MAP = {
  'A+': 4.0, 'A': 4.0, 'A-': 3.7,
  'B+': 3.3, 'B': 3.0, 'B-': 2.7,
  'C+': 2.3, 'C': 2.0, 'C-': 1.7,
  'D': 1.0, 'F': 0.0
};

let gpaCourseCount = 0;

function initGpaRows() {
  const container = document.getElementById('gpaCoursesContainer');
  if (!container) return;
  container.innerHTML = '';
  gpaCourseCount = 0;

  for (let i = 1; i <= 4; i++) {
    addGpaCourseRow();
  }
}

function addGpaCourseRow() {
  gpaCourseCount++;
  const container = document.getElementById('gpaCoursesContainer');
  if (!container) return;

  const row = document.createElement('div');
  row.className = 'dynamic-row';
  row.id = `gpaRow_${gpaCourseCount}`;
  row.innerHTML = `
    <div>
      <input type="text" class="form-input" value="Course ${gpaCourseCount}" style="height: 2.4rem; font-size: 0.88rem;">
    </div>
    <div>
      <select class="form-input gpa-grade-select" onchange="calcGPA()" style="height: 2.4rem; font-size: 0.88rem;">
        <option value="4.0">A+ (4.0)</option>
        <option value="4.0" selected>A (4.0)</option>
        <option value="3.7">A- (3.7)</option>
        <option value="3.3">B+ (3.3)</option>
        <option value="3.0">B (3.0)</option>
        <option value="2.7">B- (2.7)</option>
        <option value="2.3">C+ (2.3)</option>
        <option value="2.0">C (2.0)</option>
        <option value="1.0">D (1.0)</option>
        <option value="0.0">F (0.0)</option>
      </select>
    </div>
    <div class="input-with-addon">
      <input type="number" step="1" class="form-input gpa-credits-input" value="3" oninput="calcGPA()" style="height: 2.4rem;">
      <span class="input-addon input-addon-right" style="height: 2.4rem; font-size: 0.75rem;">Credits</span>
    </div>
    <button type="button" class="btn-remove-row" onclick="removeGpaRow(${gpaCourseCount})" title="Delete course">✕</button>
  `;
  container.appendChild(row);
}

function removeGpaRow(id) {
  const row = document.getElementById(`gpaRow_${id}`);
  if (row) {
    row.remove();
    calcGPA();
  }
}

function calcGPA() {
  const gradeSelects = document.querySelectorAll('.gpa-grade-select');
  const creditInputs = document.querySelectorAll('.gpa-credits-input');

  let totalQualityPoints = 0;
  let totalCredits = 0;

  gradeSelects.forEach((sel, i) => {
    const pts = parseFloat(sel.value);
    const cr = parseFloat(creditInputs[i]?.value) || 0;
    if (!isNaN(pts) && cr > 0) {
      totalQualityPoints += (pts * cr);
      totalCredits += cr;
    }
  });

  const gpaVal = document.getElementById('gpaResultVal');
  const totalCreditsVal = document.getElementById('gpaTotalCreditsVal');
  const qpVal = document.getElementById('gpaTotalQualityPoints');

  if (totalCredits === 0) {
    if (gpaVal) gpaVal.innerText = '0.00';
    return;
  }

  const gpa = totalQualityPoints / totalCredits;
  if (gpaVal) gpaVal.innerText = gpa.toFixed(2);
  if (totalCreditsVal) totalCreditsVal.innerText = totalCredits;
  if (qpVal) qpVal.innerText = `${totalQualityPoints.toFixed(1)} Total Quality Points`;

  recordCalculation('gpa', `Semester GPA (${totalCredits} credits)`, gpa.toFixed(2));
}

function resetGPA() {
  initGpaRows();
  calcGPA();
}

/* ==========================================================================
   18. AVERAGE CALCULATOR
   ========================================================================== */
function parseDatasetInput(raw) {
  if (!raw) return [];
  return raw
    .split(/[\s,;\n]+/)
    .map(Number)
    .filter(n => !isNaN(n));
}

function calcAverage() {
  const raw = document.getElementById('avgInputNumbers')?.value;
  const numbers = parseDatasetInput(raw);

  const meanEl = document.getElementById('avgMeanVal');
  const countEl = document.getElementById('avgCountText');
  const sumEl = document.getElementById('avgSumVal');
  const medianEl = document.getElementById('avgMedianVal');
  const minMaxEl = document.getElementById('avgMinMaxVal');
  const rangeEl = document.getElementById('avgRangeVal');

  if (numbers.length === 0) {
    if (meanEl) meanEl.innerText = '-';
    if (countEl) countEl.innerText = 'Count: 0 numbers';
    if (sumEl) sumEl.innerText = '-';
    if (medianEl) medianEl.innerText = '-';
    if (minMaxEl) minMaxEl.innerText = '-';
    if (rangeEl) rangeEl.innerText = '-';
    return;
  }

  const n = numbers.length;
  const sum = numbers.reduce((a, b) => a + b, 0);
  const mean = sum / n;

  // Sorted for min, max, median
  const sorted = [...numbers].sort((a, b) => a - b);
  const min = sorted[0];
  const max = sorted[sorted.length - 1];
  const range = max - min;

  // Median
  let median = 0;
  const mid = Math.floor(n / 2);
  if (n % 2 !== 0) {
    median = sorted[mid];
  } else {
    median = (sorted[mid - 1] + sorted[mid]) / 2;
  }

  meanEl.innerText = roundSmart(mean);
  countEl.innerText = `Count: ${n} numbers`;
  sumEl.innerText = roundSmart(sum);
  medianEl.innerText = roundSmart(median);
  minMaxEl.innerText = `${roundSmart(min)} / ${roundSmart(max)}`;
  rangeEl.innerText = roundSmart(range);

  recordCalculation('average', `Mean of ${n} numbers`, roundSmart(mean));
}

function resetAverage() {
  document.getElementById('avgInputNumbers').value = '';
  calcAverage();
}

/* ==========================================================================
   19. RATIO CALCULATOR
   ========================================================================== */
let activeRatioMode = 'solve';

function switchRatioMode(mode, btn) {
  activeRatioMode = mode;
  document.querySelectorAll('#pane-ratio .sub-tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');

  document.getElementById('ratioModeSolve').style.display = mode === 'solve' ? 'block' : 'none';
  document.getElementById('ratioModeSimplify').style.display = mode === 'simplify' ? 'block' : 'none';

  calcRatio();
}

function calcRatio() {
  const resultLabel = document.getElementById('ratioResultLabel');
  const resultVal = document.getElementById('ratioResultVal');
  const resultSub = document.getElementById('ratioResultSub');

  if (activeRatioMode === 'solve') {
    // A : B = C : D
    const aStr = document.getElementById('ratioA')?.value.trim();
    const bStr = document.getElementById('ratioB')?.value.trim();
    const cStr = document.getElementById('ratioC')?.value.trim();
    const dStr = document.getElementById('ratioD')?.value.trim();

    const a = parseFloat(aStr);
    const b = parseFloat(bStr);
    const c = parseFloat(cStr);
    const d = parseFloat(dStr);

    let solvedVariable = '';
    let solvedValue = null;

    if (isNaN(a) || aStr.toLowerCase() === 'x') {
      solvedVariable = 'A';
      if (!isNaN(b) && !isNaN(c) && !isNaN(d) && d !== 0) solvedValue = (b * c) / d;
    } else if (isNaN(b) || bStr.toLowerCase() === 'x') {
      solvedVariable = 'B';
      if (!isNaN(a) && !isNaN(c) && !isNaN(d) && c !== 0) solvedValue = (a * d) / c;
    } else if (isNaN(c) || cStr.toLowerCase() === 'x') {
      solvedVariable = 'C';
      if (!isNaN(a) && !isNaN(b) && !isNaN(d) && b !== 0) solvedValue = (a * d) / b;
    } else if (isNaN(d) || dStr.toLowerCase() === 'x') {
      solvedVariable = 'D';
      if (!isNaN(a) && !isNaN(b) && !isNaN(c) && a !== 0) solvedValue = (b * c) / a;
    }

    if (solvedValue !== null) {
      resultLabel.innerText = `Solved: ${solvedVariable}`;
      resultVal.innerText = roundSmart(solvedValue);
      resultSub.innerText = `${aStr || roundSmart(solvedValue)} : ${bStr || roundSmart(solvedValue)} = ${cStr || roundSmart(solvedValue)} : ${dStr || roundSmart(solvedValue)}`;
      recordCalculation('ratio', `Proportion solve ${solvedVariable}`, roundSmart(solvedValue));
    } else {
      resultVal.innerText = '-';
      resultSub.innerText = 'Enter 3 known values';
    }
  } else {
    // Simplify Ratio A : B
    const a = parseInt(document.getElementById('simpA')?.value);
    const b = parseInt(document.getElementById('simpB')?.value);

    if (isNaN(a) || isNaN(b) || a <= 0 || b <= 0) {
      resultVal.innerText = '-';
      resultSub.innerText = 'Enter positive integers for A and B';
      return;
    }

    const divisor = gcd(a, b);
    const simA = a / divisor;
    const simB = b / divisor;

    resultLabel.innerText = 'Simplified Lowest Terms';
    resultVal.innerText = `${simA} : ${simB}`;
    resultSub.innerText = `Greatest Common Divisor (GCD) is ${divisor}`;

    recordCalculation('ratio', `Simplify ${a} : ${b}`, `${simA} : ${simB}`);
  }
}

function gcd(a, b) {
  a = Math.abs(a);
  b = Math.abs(b);
  while (b) {
    const t = b;
    b = a % b;
    a = t;
  }
  return a;
}

function resetRatio() {
  document.getElementById('ratioA').value = '4';
  document.getElementById('ratioB').value = '12';
  document.getElementById('ratioC').value = '8';
  document.getElementById('ratioD').value = '';
  document.getElementById('simpA').value = '';
  document.getElementById('simpB').value = '';
  calcRatio();
}

/* ==========================================================================
   20. STATISTICS CALCULATOR
   ========================================================================== */
function calcStatistics() {
  const raw = document.getElementById('statsDatasetInput')?.value;
  const numbers = parseDatasetInput(raw);

  const meanEl = document.getElementById('statsMeanVal');
  const sizeEl = document.getElementById('statsSampleSize');
  const medianEl = document.getElementById('statsMedianVal');
  const modeEl = document.getElementById('statsModeVal');
  const sampleSdEl = document.getElementById('statsSampleSdVal');
  const popSdEl = document.getElementById('statsPopSdVal');
  const varEl = document.getElementById('statsVarianceVal');
  const quartilesEl = document.getElementById('statsQuartilesVal');

  if (numbers.length < 2) {
    if (meanEl) meanEl.innerText = '-';
    if (sizeEl) sizeEl.innerText = `N = ${numbers.length} values (need at least 2)`;
    if (medianEl) medianEl.innerText = '-';
    if (modeEl) modeEl.innerText = '-';
    if (sampleSdEl) sampleSdEl.innerText = '-';
    if (popSdEl) popSdEl.innerText = '-';
    if (varEl) varEl.innerText = '-';
    if (quartilesEl) quartilesEl.innerText = '-';
    return;
  }

  const n = numbers.length;
  const sum = numbers.reduce((a, b) => a + b, 0);
  const mean = sum / n;

  // Sorted
  const sorted = [...numbers].sort((a, b) => a - b);

  // Median
  const mid = Math.floor(n / 2);
  const median = n % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;

  // Mode
  const freqMap = {};
  let maxFreq = 0;
  numbers.forEach(num => {
    freqMap[num] = (freqMap[num] || 0) + 1;
    if (freqMap[num] > maxFreq) maxFreq = freqMap[num];
  });
  let modes = [];
  if (maxFreq > 1) {
    modes = Object.keys(freqMap).filter(k => freqMap[k] === maxFreq).map(Number);
  }
  const modeStr = modes.length > 0 ? modes.join(', ') : 'No Mode';

  // Variance & Standard Deviation
  const squaredDiffSum = numbers.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0);
  const sampleVariance = squaredDiffSum / (n - 1);
  const sampleSd = Math.sqrt(sampleVariance);
  const popVariance = squaredDiffSum / n;
  const popSd = Math.sqrt(popVariance);

  // Quartiles (Q1, Q3, IQR)
  const q1 = computeQuartile(sorted, 0.25);
  const q3 = computeQuartile(sorted, 0.75);
  const iqr = q3 - q1;

  meanEl.innerText = roundSmart(mean);
  sizeEl.innerText = `N = ${n} values`;
  medianEl.innerText = roundSmart(median);
  modeEl.innerText = modeStr;
  sampleSdEl.innerText = roundSmart(sampleSd);
  popSdEl.innerText = roundSmart(popSd);
  varEl.innerText = roundSmart(sampleVariance);
  quartilesEl.innerText = `Q1: ${roundSmart(q1)} | Q3: ${roundSmart(q3)} | IQR: ${roundSmart(iqr)}`;

  recordCalculation('statistics', `Mean of ${n} points`, roundSmart(mean));
}

function computeQuartile(sortedArr, q) {
  const pos = (sortedArr.length - 1) * q;
  const base = Math.floor(pos);
  const rest = pos - base;
  if (sortedArr[base + 1] !== undefined) {
    return sortedArr[base] + rest * (sortedArr[base + 1] - sortedArr[base]);
  }
  return sortedArr[base];
}

function resetStatistics() {
  document.getElementById('statsDatasetInput').value = '';
  calcStatistics();
}

/* ==========================================================================
   General Math & Formatting Helper Functions
   ========================================================================== */
function roundSmart(num) {
  if (typeof num !== 'number' || isNaN(num)) return num;
  return Math.round((num + Number.EPSILON) * 10000) / 10000;
}

function formatMoney(amount) {
  if (isNaN(amount)) return '0.00';
  return Number(amount).toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}
